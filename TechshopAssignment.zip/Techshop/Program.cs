﻿using System;
using System.Configuration;

namespace TechShop
{
    class Program
    {
        static void Main(string[] args)
        {
            string connectionString = ConfigurationManager.ConnectionStrings["Abi"].ConnectionString;
            var db = new DatabaseConnector(connectionString);

            Console.WriteLine("Connected using 'Abi' " + connectionString);

            var customerRepo = new CustomerRepository(db);
            var productRepo = new ProductRepository(db);
            var inventoryRepo = new InventoryRepository(db);
            var orderRepo = new OrderRepository(db);
            var paymentRepo = new PaymentRepository(db);
            var salesReport = new SalesReport(db);

            try
            {
                // Customer Registration
                Console.WriteLine("Register a new customer:");
                Console.Write("Customer ID: ");
                int custId = int.Parse(Console.ReadLine());

                Console.Write("First Name: ");
                string fname = Console.ReadLine();

                Console.Write("Last Name: ");
                string lname = Console.ReadLine();

                Console.Write("Email: ");
                string email = Console.ReadLine();

                Console.Write("Phone: ");
                string phone = Console.ReadLine();

                Console.Write("Address: ");
                string address = Console.ReadLine();

                var customer = new Customers(custId, fname, lname, email, phone, address, 0);
                customerRepo.RegisterCustomer(customer);
                Console.WriteLine("Customer registered.\n");

                // Product Entry
                Console.WriteLine("Add a new product:");
                Console.Write("Product ID: ");
                int prodId = int.Parse(Console.ReadLine());

                Console.Write("Product Name: ");
                string prodName = Console.ReadLine();

                Console.Write("Description: ");
                string desc = Console.ReadLine();

                Console.Write("Price: ");
                decimal price = decimal.Parse(Console.ReadLine());

                Console.Write("Category: ");
                string category = Console.ReadLine();

                Console.Write("Stock Quantity: ");
                int stock = int.Parse(Console.ReadLine());

                var product = new Products(prodId, prodName, desc, price, category, stock);
                productRepo.AddProduct(product);

                //Add Inventory
                var inventory = new Inventory(prodId + 1000, product, stock, DateTime.Now);
                inventoryRepo.AddInventory(inventory);
                Console.WriteLine("Product and Inventory added.\n");

                //Create Order
                Console.WriteLine("Create new order:");
                Console.Write("Order ID: ");
                int orderId = int.Parse(Console.ReadLine());

                var order = new Orders(orderId, customer, DateTime.Now, 0, "Pending");
                orderRepo.InsertOrder(order);

                //Order Details
                Console.Write("OrderDetail ID: ");
                int odId = int.Parse(Console.ReadLine());

                Console.Write("Quantity to Order: ");
                int qty = int.Parse(Console.ReadLine());

                var orderDetail = new OrderDetails(odId, order, product, qty);
                orderRepo.InsertOrderDetail(orderDetail);

                decimal subtotal = orderDetail.CalculateSubtotal();
                order.TotalAmount = subtotal;
                orderRepo.UpdateOrderStatus(order.OrderID, "Confirmed");
                Console.WriteLine($"Order created with subtotal: ₹{subtotal}\n");

                // Record Payment
                Console.Write("Enter payment method (e.g., UPI, Card): ");
                string method = Console.ReadLine();
                paymentRepo.RecordPayment(order.OrderID, method, subtotal);
                Console.WriteLine("Payment recorded.\n");

                //Sales Report
                Console.WriteLine("\nGenerating Sales Report for Last 7 Days:");
                salesReport.GetTotalSalesByDateRange(DateTime.Today.AddDays(-7), DateTime.Today);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"ERROR: {ex.Message}");
            }

            Console.WriteLine("\nUser-Driven ADO.NET Program Completed.");
        }
    }
}
