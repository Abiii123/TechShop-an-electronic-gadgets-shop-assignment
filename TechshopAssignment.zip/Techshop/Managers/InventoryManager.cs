﻿using System;
using System.Collections.Generic;

namespace TechShop
{
    public class InventoryManager
    {
        private SortedList<int, Inventory> inventoryList = new SortedList<int, Inventory>();

        public void AddOrUpdateInventory(Inventory inventory)
        {
            if (inventoryList.ContainsKey(inventory.Product.ProductID))
            {
                inventoryList[inventory.Product.ProductID].AddToInventory(inventory.QuantityInStock);
            }
            else
            {
                inventoryList.Add(inventory.Product.ProductID, inventory);
            }
        }

        public void DecrementInventory(int productID, int quantity)
        {
            if (!inventoryList.ContainsKey(productID))
                throw new InvalidDataException("Product not found in inventory.");

            inventoryList[productID].RemoveFromInventory(quantity);
        }

        public Inventory GetInventory(int productID)
        {
            return inventoryList.ContainsKey(productID) ? inventoryList[productID] : null;
        }

        public List<Inventory> GetAllInventory()
        {
            return new List<Inventory>(inventoryList.Values);
        }
    }
}
