﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TechShop
{
    public class OrderManager
    {
        private List<Orders> orders = new List<Orders>();

        public void AddOrder(Orders order)
        {
            orders.Add(order);
        }

        public void UpdateOrderStatus(int orderID, string newStatus)
        {
            var order = orders.FirstOrDefault(o => o.OrderID == orderID);
            if (order == null)
                throw new InvalidDataException("Order not found.");
            order.UpdateOrderStatus(newStatus);
        }

        public void RemoveCancelledOrders()
        {
            orders.RemoveAll(o => o.Status.Equals("Cancelled", StringComparison.OrdinalIgnoreCase));
        }

        public List<Orders> GetOrdersSortedByDate(bool descending = false)
        {
            return descending
                ? orders.OrderByDescending(o => o.OrderDate).ToList()
                : orders.OrderBy(o => o.OrderDate).ToList();
        }

        public List<Orders> GetAllOrders()
        {
            return orders;
        }
    }
}
