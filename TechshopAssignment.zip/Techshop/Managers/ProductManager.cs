﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace TechShop
{
    public class ProductManager
    {
        private List<Products> products = new List<Products>();

        public void AddProduct(Products product)
        {
            if (products.Any(p => p.ProductID == product.ProductID))
                throw new InvalidDataException("Product with this ID already exists.");
            products.Add(product);
        }

        public void RemoveProduct(int productID)
        {
            var product = products.FirstOrDefault(p => p.ProductID == productID);
            if (product == null)
                throw new InvalidDataException("Product not found.");
            products.Remove(product);
        }

        public Products GetProductByID(int productID)
        {
            return products.FirstOrDefault(p => p.ProductID == productID);
        }

        public List<Products> SearchProductsByCategory(string category)
        {
            return products
                .Where(p => p.Category.Equals(category, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }

        public List<Products> SearchProductsByName(string name)
        {
            return products
                .Where(p => p.ProductName.IndexOf(name, StringComparison.OrdinalIgnoreCase) >= 0)
                .ToList();
        }

        public List<Products> GetAllProducts() => products;
    }
}
