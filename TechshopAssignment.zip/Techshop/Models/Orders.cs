﻿using System;

namespace TechShop
{
    public class Orders
    {
        private int orderID;
        private DateTime orderDate;
        private decimal totalAmount;
        private string status;
        private Customers customer;

        public int OrderID
        {
            get => orderID;
            set => orderID = value > 0 ? value : throw new InvalidDataException("Order ID must be positive.");
        }

        public DateTime OrderDate
        {
            get => orderDate;
            set => orderDate = value;
        }

        public decimal TotalAmount
        {
            get => totalAmount;
            set => totalAmount = value >= 0 ? value : throw new InvalidDataException("Total must be non-negative.");
        }

        public string Status
        {
            get => status;
            set => status = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Status cannot be empty.");
        }

        public Customers Customer
        {
            get => customer;
            set => customer = value ?? throw new InvalidDataException("Customer reference required.");
        }

        public Orders(int id, Customers customer, DateTime date, decimal total, string status)
        {
            OrderID = id;
            Customer = customer;
            OrderDate = date;
            TotalAmount = total;
            Status = status;
        }

        public void GetOrderDetails()
        {
            Console.WriteLine($"Order #{OrderID} | Date: {OrderDate} | Total: ₹{TotalAmount} | Status: {Status} | Customer: {Customer.FirstName}");
        }

        public void UpdateOrderStatus(string newStatus)
        {
            Status = newStatus;
        }

        public void AddToTotal(decimal amount)
        {
            if (amount < 0)
                throw new InvalidDataException("Cannot add a negative amount.");
            TotalAmount += amount;
        }
    }
}
