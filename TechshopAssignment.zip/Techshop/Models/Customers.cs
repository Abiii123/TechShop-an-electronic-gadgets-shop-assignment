﻿using System;

namespace TechShop
{
    public class Customers
    {
        private int customerID;
        private string firstName;
        private string lastName;
        private string email;
        private string phone;
        private string address;
        private int orderCount;

        public int CustomerID
        {
            get => customerID;
            set => customerID = value > 0 ? value : throw new InvalidDataException("Customer ID must be positive.");
        }

        public string FirstName
        {
            get => firstName;
            set => firstName = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("First name cannot be empty.");
        }

        public string LastName
        {
            get => lastName;
            set => lastName = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Last name cannot be empty.");
        }

        public string Email
        {
            get => email;
            set
            {
                if (string.IsNullOrWhiteSpace(value) || !value.Contains("@") || !value.Contains("."))
                    throw new InvalidDataException("Invalid email format.");
                email = value;
            }
        }

        public string Phone
        {
            get => phone;
            set => phone = value.Length == 10 ? value : throw new InvalidDataException("Phone must be 10 digits.");
        }

        public string Address
        {
            get => address;
            set => address = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Address cannot be empty.");
        }

        public int OrderCount
        {
            get => orderCount;
            set => orderCount = value >= 0 ? value : throw new InvalidDataException("Order count must be non-negative.");
        }

        public Customers(int customerID, string firstName, string lastName, string email, string phone, string address, int orderCount)
        {
            CustomerID = customerID;
            FirstName = firstName;
            LastName = lastName;
            Email = email;
            Phone = phone;
            Address = address;
            OrderCount = orderCount;
        }

        public void GetCustomerDetails()
        {
            Console.WriteLine($"CustomerID: {CustomerID}, Name: {FirstName} {LastName}, Email: {Email}, Phone: {Phone}, Address: {Address}, Orders: {OrderCount}");
        }

        public void UpdateCustomerInfo(string newEmail, string newPhone, string newAddress)
        {
            Email = newEmail;
            Phone = newPhone;
            Address = newAddress;
            Console.WriteLine("Customer info updated.");
        }

        public void IncrementOrderCount()
        {
            OrderCount++;
        }
    }
}
