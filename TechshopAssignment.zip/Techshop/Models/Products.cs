﻿using System;

namespace TechShop
{
    public class Products
    {
        private int productID;
        private string productName;
        private string description;
        private decimal price;
        private string category;
        private int quantityInStock;

        public int ProductID
        {
            get => productID;
            set => productID = value > 0 ? value : throw new InvalidDataException("Product ID must be positive.");
        }

        public string ProductName
        {
            get => productName;
            set => productName = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Product name cannot be empty.");
        }

        public string Description
        {
            get => description;
            set => description = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Description cannot be empty.");
        }

        public decimal Price
        {
            get => price;
            set => price = value >= 0 ? value : throw new InvalidDataException("Price must be non-negative.");
        }

        public string Category
        {
            get => category;
            set => category = !string.IsNullOrWhiteSpace(value) ? value : throw new InvalidDataException("Category cannot be empty.");
        }

        public int QuantityInStock
        {
            get => quantityInStock;
            set => quantityInStock = value >= 0 ? value : throw new InvalidDataException("Quantity must be non-negative.");
        }

        public Products(int id, string name, string desc, decimal price, string category, int stock)
        {
            ProductID = id;
            ProductName = name;
            Description = desc;
            Price = price;
            Category = category;
            QuantityInStock = stock;
        }

        public void GetProductDetails()
        {
            Console.WriteLine($"ProductID: {ProductID}, Name: {ProductName}, Price: ₹{Price}, Stock: {QuantityInStock}, Category: {Category}");
        }

        public void UpdateProductInfo(string newDescription, decimal newPrice)
        {
            Description = newDescription;
            Price = newPrice;
        }

        public void ReduceStock(int quantity)
        {
            if (quantity > QuantityInStock)
                throw new InsufficientStockException("Not enough stock.");
            QuantityInStock -= quantity;
        }

        public void Restock(int quantity)
        {
            if (quantity <= 0)
                throw new InvalidDataException("Restock amount must be positive.");
            QuantityInStock += quantity;
        }
    }
}
