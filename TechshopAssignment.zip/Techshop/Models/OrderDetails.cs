﻿using System;

namespace TechShop
{
    public class OrderDetails
    {
        private int orderDetailID;
        private Orders order;
        private Products product;
        private int quantity;

        public int OrderDetailID
        {
            get => orderDetailID;
            set => orderDetailID = value > 0 ? value : throw new InvalidDataException("OrderDetail ID must be positive.");
        }

        public Orders Order
        {
            get => order;
            set => order = value ?? throw new InvalidDataException("Order reference required.");
        }

        public Products Product
        {
            get => product;
            set => product = value ?? throw new InvalidDataException("Product reference required.");
        }

        public int Quantity
        {
            get => quantity;
            set => quantity = value > 0 ? value : throw new InvalidDataException("Quantity must be positive.");
        }

        public OrderDetails(int id, Orders order, Products product, int quantity)
        {
            OrderDetailID = id;
            Order = order;
            Product = product;
            Quantity = quantity;
        }

        public decimal CalculateSubtotal()
        {
            return Quantity * Product.Price;
        }

        public void GetOrderDetailInfo()
        {
            Console.WriteLine($"OrderDetail #{OrderDetailID} | Product: {Product.ProductName} | Qty: {Quantity} | Subtotal: ₹{CalculateSubtotal()}");
        }
    }
}
