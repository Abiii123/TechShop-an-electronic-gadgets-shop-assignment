﻿using System;

namespace TechShop
{
    public class Inventory
    {
        private int inventoryID;
        private Products product;
        private int quantityInStock;
        private DateTime lastUpdated;

        public int InventoryID
        {
            get => inventoryID;
            set => inventoryID = value > 0 ? value : throw new InvalidDataException("Inventory ID must be positive.");
        }

        public Products Product
        {
            get => product;
            set => product = value ?? throw new InvalidDataException("Product reference required.");
        }

        public int QuantityInStock
        {
            get => quantityInStock;
            set => quantityInStock = value >= 0 ? value : throw new InvalidDataException("Stock must be non-negative.");
        }

        public DateTime LastUpdated
        {
            get => lastUpdated;
            set => lastUpdated = value;
        }

        public Inventory(int id, Products product, int stock, DateTime updated)
        {
            InventoryID = id;
            Product = product;
            QuantityInStock = stock;
            LastUpdated = updated;
        }

        public void AddToInventory(int quantity)
        {
            if (quantity <= 0) throw new InvalidDataException("Quantity must be positive.");
            QuantityInStock += quantity;
            LastUpdated = DateTime.Now;
        }

        public void RemoveFromInventory(int quantity)
        {
            if (quantity <= 0) throw new InvalidDataException("Quantity must be positive.");
            if (quantity > QuantityInStock) throw new InsufficientStockException("Insufficient inventory.");
            QuantityInStock -= quantity;
            LastUpdated = DateTime.Now;
        }

        public void GetInventoryInfo()
        {
            Console.WriteLine($"Inventory #{InventoryID} | Product: {Product.ProductName} | Stock: {QuantityInStock} | Last Updated: {LastUpdated}");
        }
    }
}
