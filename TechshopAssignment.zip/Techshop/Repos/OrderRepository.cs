﻿using System;
using System.Data.SqlClient;

namespace TechShop
{
    public class OrderRepository
    {
        private readonly DatabaseConnector db;

        public OrderRepository(DatabaseConnector connector)
        {
            db = connector;
        }

        public void InsertOrder(Orders order)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"INSERT INTO Orders (OrderID, CustomerID, OrderDate, TotalAmount, Status)
                                 VALUES (@OrderID, @CustomerID, @OrderDate, @TotalAmount, @Status)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@OrderID", order.OrderID);
                cmd.Parameters.AddWithValue("@CustomerID", order.Customer.CustomerID);
                cmd.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                cmd.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                cmd.Parameters.AddWithValue("@Status", order.Status);

                cmd.ExecuteNonQuery();
            }
        }

        public void InsertOrderDetail(OrderDetails od)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"INSERT INTO OrderDetails (OrderDetailID, OrderID, ProductID, Quantity)
                                 VALUES (@ODID, @OrderID, @ProductID, @Qty)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ODID", od.OrderDetailID);
                cmd.Parameters.AddWithValue("@OrderID", od.Order.OrderID);
                cmd.Parameters.AddWithValue("@ProductID", od.Product.ProductID);
                cmd.Parameters.AddWithValue("@Qty", od.Quantity);

                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateOrderStatus(int orderId, string newStatus)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = "UPDATE Orders SET Status = @Status WHERE OrderID = @OrderID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Status", newStatus);
                cmd.Parameters.AddWithValue("@OrderID", orderId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
