﻿using System;
using System.Data.SqlClient;

namespace TechShop
{
    public class CustomerRepository
    {
        private readonly DatabaseConnector db;

        public CustomerRepository(DatabaseConnector connector)
        {
            db = connector;
        }

        public void RegisterCustomer(Customers customer)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = "INSERT INTO Customers (CustomerID, FirstName, LastName, Email, Phone, Address, OrderCount) " +
                               "VALUES (@CustomerID, @FirstName, @LastName, @Email, @Phone, @Address, @OrderCount)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@CustomerID", customer.CustomerID);
                cmd.Parameters.AddWithValue("@FirstName", customer.FirstName);
                cmd.Parameters.AddWithValue("@LastName", customer.LastName);
                cmd.Parameters.AddWithValue("@Email", customer.Email);
                cmd.Parameters.AddWithValue("@Phone", customer.Phone);
                cmd.Parameters.AddWithValue("@Address", customer.Address);
                cmd.Parameters.AddWithValue("@OrderCount", customer.OrderCount);

                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateCustomerEmail(int customerId, string newEmail)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = "UPDATE Customers SET Email = @Email WHERE CustomerID = @CustomerID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Email", newEmail);
                cmd.Parameters.AddWithValue("@CustomerID", customerId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
