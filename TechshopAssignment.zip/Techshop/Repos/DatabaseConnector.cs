﻿using System;
using System.Data.SqlClient;

namespace TechShop
{

    public class DatabaseConnector
    {
        private readonly string connectionString;

        public DatabaseConnector(string connectionString)
        {
            this.connectionString = connectionString;
        }

        public SqlConnection GetConnection()
        {
            var connection = new SqlConnection(connectionString);
            connection.Open();
            return connection;
        }

        public void CloseConnection(SqlConnection connection)
        {
            if (connection != null && connection.State == System.Data.ConnectionState.Open)
            {
                connection.Close();
            }
        }
    }
}
