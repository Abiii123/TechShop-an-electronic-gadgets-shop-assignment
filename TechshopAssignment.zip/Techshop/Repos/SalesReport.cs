﻿using System;
using System.Data.SqlClient;

namespace TechShop
{
    public class SalesReport
    {
        private readonly DatabaseConnector db;

        public SalesReport(DatabaseConnector connector)
        {
            db = connector;
        }

        public void GetTotalSalesByDateRange(DateTime start, DateTime end)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"SELECT SUM(TotalAmount) AS TotalSales
                                 FROM Orders
                                 WHERE OrderDate BETWEEN @Start AND @End";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Start", start);
                cmd.Parameters.AddWithValue("@End", end);

                var result = cmd.ExecuteScalar();
                Console.WriteLine($"\nTotal Sales from {start:d} to {end:d}: ₹{result}");
            }
        }
    }
}
