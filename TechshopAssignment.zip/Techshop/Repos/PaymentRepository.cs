﻿using System;
using System.Data.SqlClient;

namespace TechShop
{
    public class PaymentRepository
    {
        private readonly DatabaseConnector db;

        public PaymentRepository(DatabaseConnector connector)
        {
            db = connector;
        }

        public void RecordPayment(int orderID, string method, decimal amount)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"INSERT INTO Payments (OrderID, PaymentMethod, Amount, PaymentDate)
                                 VALUES (@OrderID, @Method, @Amount, @Date)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@OrderID", orderID);
                cmd.Parameters.AddWithValue("@Method", method);
                cmd.Parameters.AddWithValue("@Amount", amount);
                cmd.Parameters.AddWithValue("@Date", DateTime.Now);

                cmd.ExecuteNonQuery();
            }
        }
    }
}
