﻿using System;
using System.Data.SqlClient;

namespace TechShop
{
    public class InventoryRepository
    {
        private readonly DatabaseConnector db;

        public InventoryRepository(DatabaseConnector connector)
        {
            db = connector;
        }

        public void AddInventory(Inventory inventory)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"INSERT INTO Inventory (InventoryID, ProductID, QuantityInStock, LastUpdated)
                                 VALUES (@ID, @ProductID, @Qty, @Updated)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ID", inventory.InventoryID);
                cmd.Parameters.AddWithValue("@ProductID", inventory.Product.ProductID);
                cmd.Parameters.AddWithValue("@Qty", inventory.QuantityInStock);
                cmd.Parameters.AddWithValue("@Updated", inventory.LastUpdated);
                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateStock(int productId, int newQty)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = "UPDATE Inventory SET QuantityInStock = @Qty, LastUpdated = @Updated WHERE ProductID = @ProductID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Qty", newQty);
                cmd.Parameters.AddWithValue("@Updated", DateTime.Now);
                cmd.Parameters.AddWithValue("@ProductID", productId);
                cmd.ExecuteNonQuery();
            }
        }
    }
}
