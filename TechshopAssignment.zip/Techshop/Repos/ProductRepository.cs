﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;

namespace TechShop
{
    public class ProductRepository
    {
        private readonly DatabaseConnector db;

        public ProductRepository(DatabaseConnector connector)
        {
            db = connector;
        }

        public void AddProduct(Products product)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = @"INSERT INTO Products 
                (ProductID, ProductName, Description, Price, Category, QuantityInStock) 
                VALUES (@ProductID, @ProductName, @Description, @Price, @Category, @Stock)";

                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@ProductID", product.ProductID);
                cmd.Parameters.AddWithValue("@ProductName", product.ProductName);
                cmd.Parameters.AddWithValue("@Description", product.Description);
                cmd.Parameters.AddWithValue("@Price", product.Price);
                cmd.Parameters.AddWithValue("@Category", product.Category);
                cmd.Parameters.AddWithValue("@Stock", product.QuantityInStock);

                cmd.ExecuteNonQuery();
            }
        }

        public void UpdateProductStock(int productId, int newStock)
        {
            using (SqlConnection conn = db.GetConnection())
            {
                string query = "UPDATE Products SET QuantityInStock = @Stock WHERE ProductID = @ProductID";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Stock", newStock);
                cmd.Parameters.AddWithValue("@ProductID", productId);
                cmd.ExecuteNonQuery();
            }
        }

        public List<Products> SearchByCategory(string category)
        {
            var products = new List<Products>();

            using (SqlConnection conn = db.GetConnection())
            {
                string query = "SELECT * FROM Products WHERE Category = @Category";
                SqlCommand cmd = new SqlCommand(query, conn);
                cmd.Parameters.AddWithValue("@Category", category);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    var product = new Products(
                        (int)reader["ProductID"],
                        reader["ProductName"].ToString(),
                        reader["Description"].ToString(),
                        (decimal)reader["Price"],
                        reader["Category"].ToString(),
                        (int)reader["QuantityInStock"]
                    );
                    products.Add(product);
                }
            }
            return products;
        }
    }
}
